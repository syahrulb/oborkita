<?php
class td_category_template_disable extends td_category_template {



    function render() {
        ?>


        <?php
    }


}
