<?php
/**
 * Created by ra on 6/13/2015.
 */

//logos
td_demo_media::add_image_to_media_gallery('td_header_logo',                'http://demo_content.tagdiv.com/Newsmag/sound_square/logo-header.png');
td_demo_media::add_image_to_media_gallery('td_header_logo_retina',         'http://demo_content.tagdiv.com/Newsmag/sound_square/logo-header@2x.png');
td_demo_media::add_image_to_media_gallery('td_footer_logo',                'http://demo_content.tagdiv.com/Newsmag/sound_square/logo-footer.png');
td_demo_media::add_image_to_media_gallery('td_footer_logo_retina',         'http://demo_content.tagdiv.com/Newsmag/sound_square/logo-footer@2x.png');