<?php
/**
 * Created by ra on 6/13/2015.
 */


//ads
td_demo_media::add_image_to_media_gallery('td_animals_ad_sidebar',       "http://demo_content.tagdiv.com/Newsmag/animals/ad-sidebar.jpg");
td_demo_media::add_image_to_media_gallery('td_animals_ad',               "http://demo_content.tagdiv.com/Newsmag/animals/ad.jpg");