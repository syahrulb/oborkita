<?php
/**
 * Created by ra on 6/13/2015.
 */



td_demo_media::add_image_to_media_gallery('td_pic_p3',                  "http://demo_content.tagdiv.com/Newsmag/video/p3.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_p4',                  "http://demo_content.tagdiv.com/Newsmag/video/p4.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_p5',                  "http://demo_content.tagdiv.com/Newsmag/video/p5.jpg");

//logo
td_demo_media::add_image_to_media_gallery('td_pic_logo_desktop',        'http://demo_content.tagdiv.com/Newsmag/video/logo-video.png');