<?php
/**
 * Created by ra on 6/13/2015.
 */

//logos
td_demo_media::add_image_to_media_gallery('td_logo',                'http://demo_content.tagdiv.com/Newsmag/animals/logo.png');