<?php
/**
 * Created by ra on 5/14/2015.
 */

//post images
td_demo_media::add_image_to_media_gallery('td_pic_p1',                  "http://demo_content.tagdiv.com/Newsmag/sound_square/p1.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_p2',                  "http://demo_content.tagdiv.com/Newsmag/sound_square/p2.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_1',                   "http://demo_content.tagdiv.com/Newsmag/sound_square/1.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_2',                   "http://demo_content.tagdiv.com/Newsmag/sound_square/2.jpg");





