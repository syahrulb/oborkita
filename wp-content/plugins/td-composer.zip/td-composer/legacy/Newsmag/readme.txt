    ___________________________________________
   |   __  _ ___  _   _   __  __ __  __   __   |
   |  |  \| | __|| | | |/' _/|  V  |/  \ / _]  |
   |  | | ' | _| | 'v' |`._`.| \_/ | /\ | [/\  |
   |  |_|\__|___|!_/ \_!|___/|_| |_|_||_|\__/  |
   |___________________________________________|
 
  ~ tagDiv 2016 ~
  
  
The documentations is here: 

http://forum.tagdiv.com/newsmag-documentation/


Thanks for your support and feel free to contact us any time :) . 
Our support forum is here:
http://forum.tagdiv.com/ 



~ tagDiv 2016 ~